function PlotMeanVarClasses(X,Y,type)
% function PlotMeanVarClasses(X,Y)
%
% X is a nTrls x nFeatures matrix and Y is a nTrls x 1 vector containing
% grouping for X. Type can be 'SEM','SD' or 'var'.

if nargin < 3; type = 'SEM'; end

% collapse if multiple features
if size(X,2) > 1; X = mean(X,2); end 

Y = double(Y);
nClass = length(unique(Y));
STDs   = nan(nClass,1);
Mns    = nan(nClass,1);

% get var and mean
cnt = 1;
for cl = unique(Y)'
    
    idx = Y == cl;  
    Mns(cnt) = mean(X(idx));

    switch type
        case 'SD'
            STDs(cnt) = std(X(idx));
        case 'SEM'
            STDs(cnt) = std(X(idx))./sqrt(sum(idx));
        case 'var'
            STDs(cnt) = var(X(idx));
    end

    cnt = cnt+1;
end

% plot the things
barwitherr(STDs,Mns)