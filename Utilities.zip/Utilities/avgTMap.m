%% avgerage first-level t maps

root = fullfile('\\blur\infabs\MRI\');

for i = 1:6
    file = dir(fullfile(root, sprintf('sub0%d', i), 'FirstLevel', 'Congruency_Identity', 'spmT_0001.nii'));
    [V, s{i}] = read_nii(fullfile(file.folder, file.name));
end

new = (s{1} + s{2} + s{3} + s{4} + s{5} + s{6}) / 6;
V.fname = 'avgT_0001.nii';
write_nii(V, new, fullfile(file.folder, V.fname));