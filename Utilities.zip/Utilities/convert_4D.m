function convert_4D(which_subjects, root)
% Make 4D niftis to view a movie in FSLeyes

addpath('\\blur\infabs\MRI\Analyses\spm12\matlabbatch');

load('subject_details.mat');
nSess = 6;

for SID = which_subjects
    
    fprintf('%s - CONVERTING TO 4D\n', subj{SID}.name);
    for sess = 1:nSess
        
        fprintf('SESS %d:\n', sess);
        
        % Find functional sessions
        funcFolder = fullfile(root, subj{SID}.name, 'Functional', sprintf('sess%d', sess));
        funcFiles = dir(funcFolder);
        cd(funcFolder);
        
        % Select the 3D niftis
        niiFiles = spm_select('List', fullfile(funcFiles(1).folder, funcFiles(1).name, 'f*'));
        
        % Create batch job
        matlabbatch{1}.spm.util.cat.vols = cellstr(niiFiles);
        matlabbatch{1}.spm.util.cat.name = sprintf('4D_sess%d.nii', sess);
        matlabbatch{1}.spm.util.cat.dtype = 0;
        matlabbatch{1}.spm.util.cat.RT = 3.36;
        
        % Run the job
        spm_jobman('initcfg');
        spm_jobman('run', matlabbatch);
    end
end

cd(root)
    